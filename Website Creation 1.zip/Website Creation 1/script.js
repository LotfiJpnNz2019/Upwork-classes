var reponse = "Luffy"
if ( reponse === "Luffy"){
console.log(reponse + "Reponse juste");
}

